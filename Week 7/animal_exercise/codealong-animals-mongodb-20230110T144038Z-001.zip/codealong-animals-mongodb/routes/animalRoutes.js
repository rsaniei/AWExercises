const express = require('express');
const router = express.Router();
const AnimalController = require('../controllers/AnimalController')

// API /animals
router.post('/', AnimalController.createAnimal)
router.get('/', AnimalController.getAnimals)
router.get('/:species', AnimalController.getBySpecies)
router.delete('/:name', AnimalController.deleteAnimal)

//TODO 
//router.put('/:name', AnimalController.updateAnimal)

module.exports = router;