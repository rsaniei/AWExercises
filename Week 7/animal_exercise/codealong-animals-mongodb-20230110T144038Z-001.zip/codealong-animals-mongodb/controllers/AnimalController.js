const animalModel = require("../models/animalModel");

async function getAnimals(req, res) {

    const animal = await animalModel.find().limit(req.query.limit);
    console.log(animal);   
    res.json(animal);

    //ADD ERROR HANDLING IN TRY/CATCH!
}

async function getBySpecies(req, res) {

    const animals = await animalModel.find({species: req.params.species}).sort("name");    
    console.log(animals);   
    res.json(animals);
    //ADD ERROR HANDLING IN TRY/CATCH!

}

async function createAnimal(req, res) {
    try{
        const animal = await animalModel.create({
            name: req.body.name,
            species: req.body.species,
            legs: req.body.legs
        });
        console.log(animal);
        res.json(animal);
    } catch(error) {
        console.log(error.message);
        res.status(404).json(error.message);
        return;
    }
}


async function deleteAnimal(req, res) {
    const animal = await animalModel.deleteOne({name: req.params.name});
    console.log(animal);

    res.json({message: "Animal deleted!"});
    
    //ADD ERROR HANDLING IN TRY/CATCH!

}



module.exports = {getAnimals, createAnimal, deleteAnimal, getBySpecies}