const mongoose = require("mongoose");

const animalSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true, 
        unique: true
    },
    species: {
        type: String,
        required: true
    },
    legs: {
        type: Number,
        validate: {
            validator: a => a<=8,
            message: "Too many legs!"
        }
    }
});

module.exports = new mongoose.model("Animal", animalSchema);