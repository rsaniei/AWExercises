const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        minLength: 10
    },
    age: {
        type: Number,
        validate: {
            validator: a => a>18,
            message: "You are too young to be here"
        }
    },
    pet: {
        type: mongoose.Schema.Types.ObjectId,
        ref : "Animal"
    },
    favorite_animals: [{ type: String }]
});

module.exports = new mongoose.model("User", userSchema);