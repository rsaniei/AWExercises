const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

const userRoutes = require('./routes/userRoutes');
const animalRoutes = require('./routes/animalRoutes');

const app = express();
const port = process.env.PORT || 3000;

mongoose.connect(process.env.DB_SERVER)
.then(()=> console.log("Connected to DB server"))
.catch((err) => console.log(err));


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.use('/users', userRoutes);
app.use('/animals', animalRoutes);

app.listen(port, "localhost", (err) =>{
    if(err) console.log("Server could not be started" + err);
    else console.log(`Server listening at port ${port}....`)
})



