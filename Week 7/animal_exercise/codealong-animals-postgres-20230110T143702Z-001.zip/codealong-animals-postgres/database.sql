CREATE DATABASE animals;

-- VERSION 1: create table animals

CREATE TABLE animals (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    legs INTEGER CONSTRAINT leg_check CHECK (legs<=8),
    species VARCHAR(255)
);


-- APIs and Queries:
INSERT INTO animals (name, legs, species) VALUES ('spiderman', '8', 'spider');
INSERT INTO animals (name, legs, species) VALUES ('rocky', '4', 'dog');
INSERT INTO animals (name, legs, species) VALUES ('milk', '4', 'cat');
INSERT INTO animals (name, legs, species) VALUES ('Simon', '12', 'spider'); <--- should give error

-- multiple
INSERT INTO animals (name, legs, species) VALUES
('Spot', 4, 'dog'),
('Rover', 3, 'dog'),
('Sabrina', 4, 'cat'),
('Felix', 4, 'cat'),
('Simon', 8, 'spider');

SELECT * FROM animals;
SELECT * FROM animals LIMIT 3;
SELECT * FROM animals WHERE species="dog";
SELECT * FROM animals WHERE species="dog" ORDER BY name;

INSERT INTO animals (name, legs, species) VALUES ('Simon', '5', 'spider');
UPDATE animals SET legs = 8 WHERE name = 'Simon';



-- VERSION 2: add a second table with users and a foreign key reference  to animals

CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    age INTEGER,
    email VARCHAR(255) NOT NULL UNIQUE,
    fav_animal VARCHAR(255),
    pet INTEGER REFERENCES animals
);

-- APIs and Queries:

INSERT INTO users (name, age, email, fav_animal, pet) VALUES ('Anna', '44', 'anna@gmail.com', 'dog', '3');
INSERT INTO users (name, age, email, fav_animal, pet) VALUES ('Eduard', '23', 'edu@gmail.com', 'spider', '9');




-- VERSION 3: SELECT JOIN todos and user info from both tables


SELECT users.name, users.email, animals.name AS animal_name, animals.species
FROM users
INNER JOIN animals ON users.pet=animals.id;
-- why only one name shown?? (cause both columns have same name and JSON can only have one name). How would you fix this?? (use AS)

-- find owner
SELECT * FROM users WHERE users.pet = (SELECT id FROM animals WHERE name = 'spiderman');

-- find animals for adoption <-- should be under /animals API?
SELECT * FROM animals WHERE animals.id NOT IN (SELECT pet FROM users);
-- ... or with left join
SELECT animals.id, animals.name, animals.species FROM animals LEFT JOIN users ON animals.id=users.pet WHERE user_id IS NULL;
