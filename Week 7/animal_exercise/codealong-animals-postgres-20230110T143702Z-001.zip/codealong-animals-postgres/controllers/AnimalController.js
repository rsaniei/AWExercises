const pool = require("../config/db");

//createAnimal();
async function createAnimal(req, res) {
    try{
        console.log(req.body);
        const {name, legs, species} = req.body;
        const newAnimal = await pool.query("INSERT INTO animals (name, legs, species) VALUES($1, $2, $3) RETURNING *", [name, legs, species]);        
        res.json(newAnimal.rows[0]);
    } catch(error) {
        console.error(error.message);
        res.status(404).json(error.message);
        return;
    }
}


async function getAnimals(req, res) {
    try{
        const allAnimals = await pool.query("SELECT * FROM animals LIMIT $1", [req.query.limit]);        
        res.json(allAnimals.rows);
    } catch(error) {
        console.error(error.message);
        res.status(404).json(error.message);
        return;
    }
}

async function getAnimalBySpecies(req, res) {
    try{
        console.log(req.params.species);
        const allBySpecies = await pool.query("SELECT * FROM animals WHERE species = $1 ORDER BY name", [req.params.species]);        
        res.json(allBySpecies.rows);
    } catch(error) {
        console.error(error.message);
        res.status(404).json(error.message);
        return;
    }
}


async function deleteAnimal(req, res) {
    try{
        const oneAnimal = await pool.query("SELECT * FROM todo WHERE id = $1 ", [req.params.id]);        
        res.json(oneAnimal.rows[0]);
    } catch(error) {
        console.error(error.message);
        res.status(404).json(error.message);
        return;
    }
}

async function updateAnimal(req, res) {
    try{
        const oneAnimal = await pool.query("UPDATE animals SET legs = $1 WHERE id = $2 RETURNING *", [req.params.legs, req.params.id]);        
        res.json(oneAnimal.rows[0]);
    } catch(error) {
        console.error(error.message);
        res.status(404).json(error.message);
        return;
    }
}


module.exports = {createAnimal, getAnimals, getAnimalBySpecies, deleteAnimal, updateAnimal}