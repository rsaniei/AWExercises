const pool = require("../config/db");

//createUser();
async function createUser(req, res) {
    try{
        const {name, age, email, fav_animal, pet} = req.body;
        const newUser = await pool.query("INSERT INTO todo (description) VALUES($1, $2, $3, $4, $5) RETURNING *", [name, age, email, fav_animal, pet]);        
        res.json(newUser.rows[0]);
    } catch(error) {
        console.error(error.message);
        res.status(404).json(error.message);
        return;
    }
}


async function getUsers(req, res) {
    try{
        const allUsers = await pool.query("SELECT users.name, users.email, animals.name AS animal_name, animals.species FROM users INNER JOIN animals ON users.pet=animals.id");        
        res.json(allUsers.rows);
    } catch(error) {
        console.error(error.message);
        res.status(404).json(error.message);
        return;
    }
}

async function getOwner(req, res) {
    try{
        const owner = await pool.query("SELECT * FROM users WHERE users.pet = (SELECT id FROM animals WHERE name=$1) ", [req.params.name]);        
        res.json(owner.rows);
    } catch(error) {
        console.error(error.message);
        res.status(404).json(error.message);
        return;
    }
}

module.exports = {createUser, getUsers, getOwner}