const Pool = require("pg").Pool;

const pool = new Pool({
    user: "anna",
    password: process.env.DB_PWD,
    host: "localhost",
    port: 5432,
    database: "animals"
});

module.exports = pool;
