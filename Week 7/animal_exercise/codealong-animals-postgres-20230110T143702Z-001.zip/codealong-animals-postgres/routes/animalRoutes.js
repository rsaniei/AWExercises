const express = require('express');
const router = express.Router();
const AnimalController = require('../controllers/AnimalController');

//create animal - POST
router.post('/', AnimalController.createAnimal)

//get animal - GET
router.get('/', AnimalController.getAnimals)

//get all animal by species - GET
router.get('/:species', AnimalController.getAnimalBySpecies)

//delete specific animal by ID - DELETE
router.delete('/:id', AnimalController.deleteAnimal)

//delete specific animal by ID - DELETE
router.put('/:id/:legs', AnimalController.updateAnimal)

module.exports = router;