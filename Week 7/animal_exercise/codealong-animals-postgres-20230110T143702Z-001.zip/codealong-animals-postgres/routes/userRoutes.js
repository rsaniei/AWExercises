const express = require('express');
const router = express.Router();
const UserController = require('../controllers/UserController');

//create user - POST
router.post('/', UserController.createUser)

//get all users - GET
router.get('/', UserController.getUsers)

//get one specific user by pet name - GET
router.get('/owner/:name', UserController.getOwner)

module.exports = router;