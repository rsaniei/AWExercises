const express = require('express');
const app = express();
const dotenv = require("dotenv");
dotenv.configure();
const cors = require("cors");
const animalRoutes = require("./routes/animalRoutes");
const userRoutes = require("./routes/userRoutes");
const port = process.env.PORT || 3000;


app.use(cors());
app.use(express.json());

app.use('/animals', animalRoutes);
app.use('/users', userRoutes);

app.listen(port, "localhost", (err) =>{
    if(err) console.log("Server could not be started" + err);
    else console.log(`Server listening at port ${port}....`)
})



